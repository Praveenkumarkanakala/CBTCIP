import React, { useState } from 'react';
import { Link } from 'react-router-dom'; // Import Link component
import './available.css';

const RegisterPage = () => {
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        eventType: '',
        startDate: '',
        endDate: '',
        eventName: '', 
        venue: '', 
        budget: '' 
    });
    const [submitted, setSubmitted] = useState(false);
    const availableEvents = [
        {
            id: 1,
            name: 'Wedding Ceremony',
            type: 'Personal',
            venue: 'Taj Falaknuma Palace',
            budget: '$30,000',
            date: '2024-05-15'
        },
        {
            id: 2,
            name: 'Corporate Conference',
            type: 'Professional',
            venue: 'The Westin Hyderabad Mindspace',
            budget: '$50,000',
            date: '2024-06-20'
        },
        {
            id: 3,
            name: 'Birthday Party',
            type: 'Family',
            venue: 'Golkonda Resorts and Spa',
            budget: '$10,000',
            date: '2024-07-10'
        },
        {
            id: 4,
            name: 'Product Launch',
            type: 'Professional',
            venue: 'Hitex Exhibition Center',
            budget: '$40,000',
            date: '2024-08-05'
        },
        {
            id: 5,
            name: 'Music Concert',
            type: 'Entertainment',
            venue: 'Gachibowli Stadium',
            budget: '$60,000',
            date: '2024-09-15'
        }
    ];
    

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = e => {
        e.preventDefault();
        // Handle form submission
    };

    return (
        <div className="register-page-container">
            {!submitted ? (
                <div className="event-cards-container">
                    <h2>Available Events</h2>
                    <div className="event-cards">
                        {availableEvents.map(event => (
                            <div key={event.id} className="event-card">
                                <h3>{event.name}</h3>
                                <p>Type: {event.type}</p>
                                <p>Venue: {event.venue}</p>
                                <p>Budget: {event.budget}</p>
                                <p>Date: {event.date}</p>
                                <Link to="/eventform">
                                    <button onClick={() => setFormData({ ...formData, startDate: event.date })}>Register</button>
                                </Link>
                            </div>
                        ))}
                    </div>
                </div>
            ) : (
                // Display a confirmation message or component when submitted
                <div>
                    <h2>Registration Submitted</h2>
                    {/* You can display a confirmation message or redirect the user to another page */}
                </div>
            )}
        </div>
    );
};

export default RegisterPage;
