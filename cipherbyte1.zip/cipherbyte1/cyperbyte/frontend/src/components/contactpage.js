// ContactPage.js

import React from 'react';
import './contactPage.css';

const ContactPage = () => {
  return (
    <div className="contact-container">
      <h2>Contact Us</h2>
      <div className="contact-details" >
        <p>Email: info@eventplanner360.com</p>
        <p>Phone: +1 (123) 456-7890</p>
        {/* Add any other contact details you want to display */}
      </div>
    </div>
  );
}

export default ContactPage;
