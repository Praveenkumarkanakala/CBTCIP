import React, { useState, useEffect } from 'react';
import backgroundImage from './event4.jpg'; 

function Ev() {
  const [registrations, setRegistrations] = useState([]);

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    try {
      const response = await fetch('http://localhost:5000/api/registrations');
      const data = await response.json();
      setRegistrations(data);
    } catch (error) {
      console.error('Error fetching data:', error);
    }
  };

  return (
    <div style={{ backgroundImage: `url(${backgroundImage})`, backgroundSize: 'cover', minHeight: '110vh' }}>
      {/* Added background image and styles */}
      <h1>Registrations</h1>
      <table>
        <thead>
          <tr>
            <th>Name</th>
            <th>Phone</th>
            <th>Email</th>
            <th>Event Type</th>
            <th>Start Date</th>
            <th>End Date</th>
            <th>Event Name</th>
            <th>Venue</th>
          </tr>
        </thead>
        <tbody>
          {registrations.map(registration => (
            <tr key={registration._id}>
              <td>{registration.name}</td>
              <td>{registration.phone}</td>
              <td>{registration.email}</td>
              <td>{registration.eventType}</td>
              <td>{registration.startDate}</td>
              <td>{registration.endDate}</td>
              <td>{registration.eventName}</td>
              <td>{registration.venue}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Ev;
