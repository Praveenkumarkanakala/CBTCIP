// Login.js

import React, { useState } from 'react';
import axios from 'axios';
import { Link, useNavigate } from 'react-router-dom';
import './login.css';

const Login = ({ setLoginUser }) => {
    const navigate = useNavigate();
    const [user, setUser] = useState({
        email: "",
        password: ""
    });

    const handleChange = e => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        });
    };

    const login = (e) => {
        e.preventDefault(); // prevent default form submission
        axios.post("http://localhost:3000/Login", user)
            .then(res => {
                alert(res.data.message);
                setLoginUser(res.data.user);
                navigate("/home"); // Redirect to home page
            })
            .catch(error => {
                console.error("Login error:", error);
                alert("Login failed. Please try again.");
            });
    };

    return (
        <div className="container">
            <div className="card">
                <div className="card_title">
                    <h1>Login to your account</h1>
                </div>
                <div className="form">
                    <form onSubmit={login}>
                        <div className="input_field">
                            <label htmlFor="email">Email</label>
                            <input type="text" id="email" name="email" placeholder="Enter your email address" required onChange={handleChange} />
                        </div>
                        <div className="input_field">
                            <label htmlFor="password">Password</label>
                            <input type="password" id="password" name="password" placeholder="Enter your password" required onChange={handleChange} />
                        </div>
                        <div className="checkbox_field">
                            <input type="checkbox" id="remember_me" name="remember_me" />
                            <label htmlFor="remember_me">Remember Me</label>
                        </div>
                        <button type="submit" className="btn">Login</button>
                    </form>
                    <p>New to MyApp? <Link to="/register">Sign Up</Link></p>
                </div>
            </div>
        </div>
    );
};

export default Login;
