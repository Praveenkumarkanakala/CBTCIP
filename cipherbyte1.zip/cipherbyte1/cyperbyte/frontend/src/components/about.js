import React, { useState } from 'react';
import './about.css'; // Import the CSS file for styling

const AboutPage = () => {
  const [expanded, setExpanded] = useState(false);

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  return (
    <div className="about-container">
      <h2>About Event Planner360</h2>
      <p>Event Planner360 is not just another event management platform – it's the ultimate companion in crafting unforgettable experiences. We grasp the essence of uniqueness in every event, and our comprehensive toolkit is tailored to empower you to manifest your vision, irrespective of the event scale or theme.</p>
      <p>From cozy gatherings to grandiose conventions, Event Planner360 equips you with the arsenal necessary for seamless event planning, organization, and execution. Our user-friendly interface streamlines event creation, guest list management, budget tracking, vendor coordination, and activity scheduling, all within a centralized hub.</p>
      {expanded && (
        <div>
          <p>But our dedication doesn't end there. We are devoted to enhancing every facet of the event planning journey to deliver unparalleled experiences for both organizers and attendees alike. That's why we offer personalized event pages, robust invitation management features, and meticulous RSVP tracking to ensure each guest feels valued and engaged.</p>
          <p>With seamless integration with leading payment gateways, Event Planner360 transforms ticket sales and online transactions into a breeze, eliminating the hassle of manual processing and paperwork. This integration fosters collaboration among organizers, vendors, and attendees, facilitating smooth communication and coordination throughout the event lifecycle.</p>
          <p>At Event Planner360, we are committed to simplifying event planning while elevating the overall experience for all involved. Whether it's a wedding, conference, or social gathering, count on Event Planner360 to be your steadfast ally every step of the way. Let's craft unforgettable moments together.</p>
        </div>
      )}
      <button onClick={toggleExpanded}>{expanded ? 'Read Less' : 'Read More'}</button>
      
      {/* First Card */}
      <div className="card">
        <h3>Why Choose Event Planner360?</h3>
        <ul>
          <li>Comprehensive toolkit for all event scales and themes</li>
          <li>Intuitive interface for seamless event management</li>
          <li>Personalized event pages and invitation management</li>
        </ul>
      </div>

      {/* Second Card */}
      <div className="card">
        <h3>Key Features</h3>
        <ul>
          <li>Integration with leading payment gateways for smooth transactions</li>
          <li>Commitment to simplifying event planning and enhancing experiences</li>
          <li>24/7 customer support for your peace of mind</li>
        </ul>
      </div>
    </div>
  );
}

export default AboutPage;
