import React from 'react';
import { Link } from 'react-router-dom';
import './home.css'; // Import the CSS file for styling

const HomePage = () => {
  return (
    <div className="home-container">
      <header>
        <nav>
          <h1>Event Planner 360</h1> {/* Display Event Planner 360 on the left */}
          <ul>
            <li><Link to="/about">About</Link></li>
            <li><Link to="/eventlist">Events</Link></li>
            <li><Link to="/contact">Contact</Link></li>
            <li><Link to="/createevent">Create Event</Link></li>
            <li><Link to="/availableevents">Available Events</Link></li>
            <li><Link to="/register">Signup</Link></li>
            <li><Link to="/login">Signin</Link></li>
          </ul>
        </nav>
      </header>
      <main>
        <section className="intro-section">
          <h2>About Event Planner 360</h2>
          <p>Event Planner 360 is your one-stop destination for all event planning needs. From weddings to corporate conferences, we specialize in creating unforgettable experiences tailored to your requirements.</p>
        </section>
      </main>
      
    </div>
  );
};

export default HomePage;
