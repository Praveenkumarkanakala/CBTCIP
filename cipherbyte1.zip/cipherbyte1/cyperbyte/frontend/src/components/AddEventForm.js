import React, { useState } from 'react';
import axios from 'axios';
import RegistrationConfirmationPage from './RegistrationConfirmationPage'; 

const RegisterPage = () => {
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        eventType: '',
        startDate: '',
        endDate: '',
        eventName: '', 
        venue: '', 
        budget: '' 
    });
    const [submitted, setSubmitted] = useState(false); 

    const handleChange = e => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const handleSubmit = e => {
        e.preventDefault();
        axios.post('http://localhost:5000/api/register', formData)
            .then(response => {
                console.log('Registration successful: ', response.data);
                setSubmitted(true); 
            })
            .catch(error => {
                console.error('Error registering: ', error);
            });
    };

    const venueOptions = [
        'Taj Falaknuma Palace',
        'The Westin Hyderabad Mindspace',
        'Novotel Hyderabad Airport',
        'Hitex Exhibition Center',
        'Taj Krishna',
        'Golkonda Resorts and Spa',
        'Chowmahalla Palace',
    ];

    const eventTypeOptions = ['Family', 'Professional', 'Personal'];

    return (
        <div style={{ backgroundColor: '#ffb6c1', backgroundImage: 'linear-gradient(to bottom, #ffb6c1, #87ceeb)', padding: '20px' }}>

            {!submitted ? ( 
                <div style={{ maxWidth: '500px', margin: 'auto', padding: '20px', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)', borderRadius: '5px', backgroundColor: '#f5f5f5' }}>
                    <h2 style={{ marginBottom: '20px', textAlign: 'center' }}>Register</h2>
                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Name:</label>
                            <input type="text" name="name" value={formData.name} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Phone:</label>
                            <input type="tel" name="phone" value={formData.phone} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Email:</label>
                            <input type="email" name="email" value={formData.email} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Event Name:</label>
                            <input type="text" name="eventName" value={formData.eventName} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Venue:</label>
                            <select name="venue" value={formData.venue} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required>
                                <option value="">Select Venue</option>
                                {venueOptions.map((venue, index) => (
                                    <option key={index} value={venue}>{venue}</option>
                                ))}
                            </select>
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Event Type:</label>
                            <select name="eventType" value={formData.eventType} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required>
                                <option value="">Select Event Type</option>
                                {eventTypeOptions.map((type, index) => (
                                    <option key={index} value={type}>{type}</option>
                                ))}
                            </select>
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Budget:</label>
                            <input type="number" name="budget" value={formData.budget} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required min={30000} max={200000} />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Start Date:</label>
                            <input type="date" name="startDate" value={formData.startDate} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>End Date:</label>
                            <input type="date" name="endDate" value={formData.endDate} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                        </div>
                        <button type="submit" style={{ backgroundColor: '#007bff', color: '#fff', padding: '10px 20px', borderRadius: '5px', border: 'none', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold' }}>Register</button>
                    </form>
                </div>
            ) : ( 
                <RegistrationConfirmationPage formData={formData} />
            )}
        </div>
    );
};

export default RegisterPage;
