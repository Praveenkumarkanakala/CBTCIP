import React, { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate} from 'react-router-dom';
import EventList from './components/EventList';
import AddEventForm from './components/AddEventForm';
import Homepage from './components/Homepage';
import ContactPage from './components/contactpage';
import AboutPage from './components/about';
import Login from './components/login/Login';
import Register from './components/register/Register';
import RegistrationConfirmationPage from './components/RegistrationConfirmationPage';
import Ev from './components/eventlab';


function App() {
  const [loginUser, setLoginUser] = useState(null);

  return (
    <Router>
      <Routes>
        <Route path="/" element={<Login setLoginUser={setLoginUser} />} />
        <Route path="/register" element={<Register />} />
        <Route path="/home" element={<Homepage />} />
        <Route path="/eventform" element={<AddEventForm />} />
        <Route path="/eventlist" element={<EventList />} />
        <Route path="/confirmation" element={<RegistrationConfirmationPage />} />
        <Route path="/createevent" element={<AddEventForm />} />
        <Route path="/contact" element={<ContactPage />} />
        <Route path="/about" element={<AboutPage />} />
        <Route path="/availableevents" element={<Ev />} />
        {loginUser && <Route path="/" element={<Navigate to="/home" />} />}
        <Route path="*" element={<Navigate to="/" />} />
      </Routes>
    </Router>
  );
}

export default App;
