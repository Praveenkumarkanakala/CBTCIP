// src/PaymentForm.js

import React, { useState } from 'react';
import axios from 'axios';

const PaymentForm = () => {
    const [formData, setFormData] = useState({
        orderId: '',
        orderAmount: 0,
        customerName: '',
        customerPhone: '',
        customerEmail: ''
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });
    };

    const handleSubmit = async (e) => {
       // e.preventDefault();

        try {
            const response = await axios.post('http://localhost:3000/create-order', formData);
            // Redirect to Cashfree payment page
            window.location.href = response.data.paymentLink;
        } catch (error) {
            console.error('Error creating order:', error);
        }
    };

    return (
        <form onSubmit={handleSubmit}>
            <input type="text" name="orderId" placeholder="Order ID" value={formData.orderId} onChange={handleChange} required />
            <input type="number" name="orderAmount" placeholder="Amount" value={formData.orderAmount} onChange={handleChange} required />
            <input type="text" name="customerName" placeholder="Customer Name" value={formData.customerName} onChange={handleChange} required />
            <input type="text" name="customerPhone" placeholder="Customer Phone" value={formData.customerPhone} onChange={handleChange} required />
            <input type="email" name="customerEmail" placeholder="Customer Email" value={formData.customerEmail} onChange={handleChange} required />
            <button type="submit">Pay Now</button>
        </form>
    );
};

export default PaymentForm;
