import React, { useState } from "react";
import "../register/register.css"; // Corrected import path
import axios from "axios";
import { useNavigate } from "react-router-dom";

const Register = () => {
    const navigate = useNavigate();

    const [user, setUser] = useState({
        name: "",
        email: "",
        password: ""
    });

    const handleChange = (e) => {
        const { name, value } = e.target;
        setUser({
            ...user,
            [name]: value
        });
    };

    const register = async (e) => {
        e.preventDefault(); // Prevent default form submission

        try {
            const response = await axios.post("http://localhost:3000/Register", user); // Corrected port number
            alert(response.data.message);
            navigate("/login");
        } catch (error) {
            console.error("Registration failed:", error);
            alert("Registration failed. Please try again later.");
        }
    };

    return (
        <div className="container">
            <div className="form-container">
                <h2>Create Account</h2>
                <form onSubmit={register}>
                    <div className="input-field">
                        <label htmlFor="name">Name</label>
                        <input type="text" id="name" name="name" placeholder="Enter your name" required onChange={handleChange} />
                    </div>
                    <div className="input-field">
                        <label htmlFor="email">Email</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email" required onChange={handleChange} />
                    </div>
                    <div className="input-field">
                        <label htmlFor="password">Password</label>
                        <input type="password" id="password" name="password" placeholder="Enter your password" required onChange={handleChange} />
                    </div>
                    <div className="remember-me">
                        <input type="checkbox" id="remember-me" name="remember-me" />
                        <label htmlFor="remember-me">Remember Me</label>
                    </div>
                    <button type="submit" className="btn">Sign Up</button>
                </form>
                <p className="already-have-account">Already have an account? <a href="/login">Login</a></p>
            </div>
        </div>
    );
};

export default Register;
