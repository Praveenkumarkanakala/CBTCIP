// src/Transactions.js

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Paper } from '@mui/material';

const Transactions = () => {
    const [transactions, setTransactions] = useState([]);

    useEffect(() => {
        const fetchTransactions = async () => {
            try {
                const response = await axios.get('http://localhost:3000/transactions');
                setTransactions(response.data);
            } catch (error) {
                console.error('Error fetching transactions:', error);
            }
        };

        fetchTransactions();
    }, []);

    return (
        <TableContainer component={Paper}>
            <Table>
                <TableHead>
                    <TableRow>
                        <TableCell>Order ID</TableCell>
                        <TableCell>Amount</TableCell>
                        <TableCell>Reference ID</TableCell>
                        <TableCell>Status</TableCell>
                        <TableCell>Payment Mode</TableCell>
                        <TableCell>Message</TableCell>
                        <TableCell>Transaction Time</TableCell>
                        <TableCell>Created At</TableCell>
                    </TableRow>
                </TableHead>
                <TableBody>
                    {transactions.map((transaction) => (
                        <TableRow key={transaction._id}>
                            <TableCell>{transaction.orderId}</TableCell>
                            <TableCell>{transaction.orderAmount}</TableCell>
                            <TableCell>{transaction.referenceId}</TableCell>
                            <TableCell>{transaction.txStatus}</TableCell>
                            <TableCell>{transaction.paymentMode}</TableCell>
                            <TableCell>{transaction.txMsg}</TableCell>
                            <TableCell>{transaction.txTime}</TableCell>
                            <TableCell>{new Date(transaction.createdAt).toLocaleString()}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
        </TableContainer>
    );
};

export default Transactions;
