import React from 'react';
import './Events.css';
import { Link } from 'react-router-dom';

const EventList = ({ eventName, eventType, venue, description, price }) => {
    const handleRegister = () => {
        
        console.log(`Registered for ${eventName}`);
    };

    return (
        <div className="event-card">
            <h2>{eventName}</h2>
            <p>Event Type: {eventType}</p>
            <p>Venue: {venue}</p>
            <p>Description: {description}</p>
            <p>Price: ${price}</p>
            <Link to="/eventform">
                <button onClick={handleRegister}>Create Events</button>
            </Link>
        </div>
    );
};

const eventsData = [
    {
        eventName: "Birthday Celebrations",
        eventType: "Family",
        venue: "Seminar Grounds",
        description: "The birthday celebrations will be an enchanting affair, featuring a delightful array of activities and surprises. From heartwarming speeches to lively music and delicious treats, there will be something for everyone to enjoy. It's a time to come together and create lasting memories, as we honor the special individual whose presence brightens our lives.",
        price: 5000
    },
    {
        eventName: "Marriage Event",
        eventType: "Wedding",
        venue: "Convention Center",
        description: "Join us as we celebrate the union of two souls in matrimony. The marriage event will be a grand affair filled with love, laughter, and unforgettable moments. Witness the beautiful traditions and rituals as we embark on this journey together.",
        price: 10000
    },
    {
        eventName: "Half Saree Function",
        eventType: "Traditional",
        venue: "Community Hall",
        description: "Experience the richness of tradition at the half saree function. This cultural celebration marks an important milestone in a young girl's life as she transitions into womanhood. Join us for an evening of traditional rituals, vibrant attire, and joyful festivities.",
        price: 3000
    },
    {
        eventName: "House Opening Function",
        eventType: "Housewarming",
        venue: "New Residence",
        description: "Celebrate the beginning of a new chapter as we open the doors to our new home. Join us for a housewarming ceremony filled with warmth, blessings, and good wishes. It's a time to cherish memories and create new ones in our humble abode.",
        price: 0 // Free entry
    },
    {
        eventName: "Gathering Party",
        eventType: "Social",
        venue: "Community Park",
        description: "Come together for a gathering party filled with camaraderie and fun. Whether you're catching up with old friends or making new ones, this casual get-together promises good vibes and great company. Let's make memories under the open sky.",
        price: 0 // Free entry
    },
    {
        eventName: "Corporate Conference",
        eventType: "Business",
        venue: "Convention Center",
        description: "Engage in insightful discussions and networking opportunities at our corporate conference. Gain valuable knowledge, connect with industry experts, and explore new business prospects. Join us as we shape the future of business together.",
        price: 200 // Ticket price for professionals
    }
];

const Events = () => {
    return (
        <div className="events-container">
            {eventsData.map(event => (
                <EventList
                    key={event.eventName}
                    eventName={event.eventName}
                    eventType={event.eventType}
                    venue={event.venue}
                    description={event.description}
                    price={event.price}
                />
            ))}
        </div>
    );
};

export default Events;
