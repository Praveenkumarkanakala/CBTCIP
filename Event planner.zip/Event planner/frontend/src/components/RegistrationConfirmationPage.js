import React, { useState } from 'react';
import QRCode from 'qrcode.react';

const RegistrationConfirmationPage = ({ formData, payeeName, amount }) => {
    const [showQRCode, setShowQRCode] = useState(false);

    const handlePayNowClick = () => {
        setShowQRCode(true); // Set state to show QR code after button click
    };

    return (
        <div style={{ backgroundColor: '#ffb6c1', backgroundImage: 'linear-gradient(to bottom, #ffb6c1, #87ceeb)', padding: '20px' }}>
            <div style={{ maxWidth: '500px', margin: 'auto', padding: '20px', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)', borderRadius: '5px', backgroundColor: '#f5f5f5' }}>
                <h2 style={{ marginBottom: '20px', textAlign: 'center' }}>Registration Confirmation</h2>
                <div style={{ marginBottom: '20px' }}>
                    <p><strong>Name:</strong>     {formData.name}</p>
                    <p><strong>Phone:</strong>    {formData.phone}</p>
                    <p><strong>Email:</strong>    {formData.email}</p>
                    <p><strong>Event Name:</strong>   {formData.eventName}</p>
                    <p><strong>Venue:</strong>        {formData.venue}</p>
                    <p><strong>Event Type:</strong>   {formData.eventType}</p>
                    <p><strong>Budget:</strong>       {formData.budget}</p>
                    <p><strong>Start Date:</strong>   {formData.startDate}</p>
                    <p><strong>End Date:</strong> {formData.endDate}</p>
                    {showQRCode ? (
                        <div style={{ textAlign: 'center' }}>
                            <QRCode value={`upi://pay?pa=${encodeURIComponent(payeeName)}&pn=${encodeURIComponent(formData.name)}&am=${amount}&cu=INR`} size={200} />
                            <p style={{ fontSize: '14px', marginTop: '10px', fontStyle: 'italic' }}>Scan the QR code to make the payment.</p>
                        </div>
                    ) : (
                        <button onClick={handlePayNowClick} style={{ backgroundColor: '#007bff', color: '#fff', padding: '10px 20px', borderRadius: '5px', border: 'none', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold', display: 'block', margin: 'auto' }}>Pay Now</button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default RegistrationConfirmationPage;
