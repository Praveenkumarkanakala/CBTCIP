import React, { useState } from 'react';
import axios from 'axios';
import RegistrationConfirmationPage from './RegistrationConfirmationPage'; 

const RegisterPage = () => {
    const [formData, setFormData] = useState({
        name: '',
        phone: '',
        email: '',
        eventType: '',
        startDate: '',
        endDate: '',
        eventName: '', 
        venue: '', 
        budget: '' 
    });
    const [errors, setErrors] = useState({});
    const [submitted, setSubmitted] = useState(false); 

    const handleChange = e => {
        const { name, value } = e.target;
        setFormData({ ...formData, [name]: value });

        // Clear the specific field error on change
        setErrors({ ...errors, [name]: '' });
    };

    const validate = () => {
        const newErrors = {};
        const phonePattern = /^[0-9]{10}$/;
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!formData.name) newErrors.name = 'Name is required';
        if (!formData.phone) newErrors.phone = 'Phone is required';
        else if (!phonePattern.test(formData.phone)) newErrors.phone = 'Phone must be 10 digits';
        if (!formData.email) newErrors.email = 'Email is required';
        else if (!emailPattern.test(formData.email)) newErrors.email = 'Email is invalid';
        if (!formData.eventName) newErrors.eventName = 'Event Name is required';
        if (!formData.venue) newErrors.venue = 'Venue is required';
        if (!formData.eventType) newErrors.eventType = 'Event Type is required';
        if (!formData.budget) newErrors.budget = 'Budget is required';
        if (!formData.startDate) newErrors.startDate = 'Start Date is required';
        if (!formData.endDate) newErrors.endDate = 'End Date is required';

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = e => {
        e.preventDefault();
        if (validate()) {
            axios.post('http://localhost:3000/api/register', formData)
                .then(response => {
                    console.log('Registration successful: ', response.data);
                    setSubmitted(true);
                })
                .catch(error => {
                    console.error('Error registering: ', error);
                });
        }
    };

    const venueOptions = [
        'Taj Falaknuma Palace',
        'The Westin Hyderabad Mindspace',
        'Novotel Hyderabad Airport',
        'Hitex Exhibition Center',
        'Taj Krishna',
        'Golkonda Resorts and Spa',
        'Chowmahalla Palace',
    ];

    const eventTypeOptions = ['Family', 'Professional', 'Personal'];

    return (
        <div style={{ backgroundColor: '#ffb6c1', backgroundImage: 'linear-gradient(to bottom, #ffb6c1, #87ceeb)', padding: '20vh' }}>

            {!submitted ? ( 
                <div style={{ maxWidth: '500px', margin: 'high', padding: '10vh', boxShadow: '0 0 10px rgba(0, 0, 0, 0.1)', borderRadius: '5px', backgroundColor: '#f5f5f5' }}>
                    <h2 style={{ marginBottom: '10px', textAlign: 'center' }}>Register</h2>
                    <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column' }}>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Name:</label>
                            <input type="text" name="name" value={formData.name} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.name && <span style={{ color: 'red' }}>{errors.name}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Phone:</label>
                            <input type="number" name="phone" value={formData.phone} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.phone && <span style={{ color: 'red' }}>{errors.phone}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Email:</label>
                            <input type="email" name="email" value={formData.email} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.email && <span style={{ color: 'red' }}>{errors.email}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Event Name:</label>
                            <input type="text" name="eventName" value={formData.eventName} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.eventName && <span style={{ color: 'red' }}>{errors.eventName}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Venue:</label>
                            <select name="venue" value={formData.venue} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required>
                                <option value="">Select Venue</option>
                                {venueOptions.map((venue, index) => (
                                    <option key={index} value={venue}>{venue}</option>
                                ))}
                            </select>
                            {errors.venue && <span style={{ color: 'red' }}>{errors.venue}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Event Type:</label>
                            <select name="eventType" value={formData.eventType} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required>
                                <option value="">Select Event Type</option>
                                {eventTypeOptions.map((type, index) => (
                                    <option key={index} value={type}>{type}</option>
                                ))}
                            </select>
                            {errors.eventType && <span style={{ color: 'red' }}>{errors.eventType}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Budget:</label>
                            <input type="number" name="budget" value={formData.budget} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required min={30000} max={200000} />
                            {errors.budget && <span style={{ color: 'red' }}>{errors.budget}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>Start Date:</label>
                            <input type="date" name="startDate" value={formData.startDate} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.startDate && <span style={{ color: 'red' }}>{errors.startDate}</span>}
                        </div>
                        <div style={{ marginBottom: '20px' }}>
                            <label style={{ marginBottom: '5px' }}>End Date:</label>
                            <input type="date" name="endDate" value={formData.endDate} onChange={handleChange} style={{ width: '100%', padding: '10px', borderRadius: '5px', border: '1px solid #ccc' }} required />
                            {errors.endDate && <span style={{ color: 'red' }}>{errors.endDate}</span>}
                        </div>
                        <button type="submit" style={{ backgroundColor: '#007bff', color: '#fff', padding: '10px 20px', borderRadius: '5px', border: 'none', cursor: 'pointer', fontSize: '16px', fontWeight: 'bold' }}>Register</button>
                    </form>
                </div>
            ) : ( 
                <RegistrationConfirmationPage formData={formData} />
            )}
        </div>
    );
};

export default RegisterPage;
