const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(bodyParser.json());
app.use(cors());

// Database setup
mongoose.connect("mongodb://127.0.0.1:27017/eventplanner", {
    useNewUrlParser: true,
    useUnifiedTopology: true,
}).then(() => {
    console.log('Database connected..');
}).catch(err => console.error('Error connecting to database:', err));

// Define Schema
const registrationSchema = new mongoose.Schema({
    name: { type: String, required: true },
    phone: { type: String, required: true },
    email: { type: String, required: true },
    eventType: { type: String, required: true },
    startDate: { type: Date, required: true },
    endDate: { type: Date, required: true },
    eventName: { type: String, required: true },
    venue: { type: String, required: true }
});

// Define Model
const Registration = mongoose.model('Registration', registrationSchema);

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true },
    password: { type: String, required: true }
});

const User = mongoose.model("User", userSchema);

// Login endpoint
app.post("/login", async (req, res) => {
    const { email, password } = req.body;
    try {
        const user = await User.findOne({ email: email });
        if (user) {
            if (password === user.password) {
                res.send({ message: "Login success", user: user });
            } else {
                res.status(401).send({ message: "Wrong credentials" });
            }
        } else {
            res.status(404).send({ message: "User not found" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
});

// Register endpoint
app.post("/register", async (req, res) => {
    const { name, email, password } = req.body;
    try {
        const existingUser = await User.findOne({ email: email });
        if (existingUser) {
            res.status(409).send({ message: "User already exists" });
        } else {
            const newUser = new User({ name, email, password });
            await newUser.save();
            res.status(201).send({ message: "Registration successful" });
        }
    } catch (error) {
        console.error(error);
        res.status(500).send("Internal Server Error");
    }
});

// Get all registrations
app.get('/api/registrations', async (req, res) => {
    try {
        const registrations = await Registration.find();
        res.json(registrations);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

// Create new registration
app.post('/api/register', async (req, res) => {
    const registration = new Registration(req.body);
    try {
        const newRegistration = await registration.save();
        res.status(201).json(newRegistration);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});



// Server start
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
