// models/Event.js
const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  date: {
    type: Date,
    required: true
  },
  venue: {
    type: String,
    required: true
  },
  budget: {
    type: Number,
    required: true
  },
  guests: [{
    name: {
      type: String,
      required: true
    },
    email: {
      type: String,
      required: true
    },   
  }],
  vendors: [{
    name: {
      type: String,
      required: true
    },
    contact: {
      type: String,
      required: true
    },   
  }],
  schedule: [{
    startTime: {
      type: Date,
      required: true
    },
    endTime: {
      type: Date,
      required: true
    },
    activity: {
      type: String,
      required: true
    },
  }],
  invitations: [{
    email: {
      type: String,
      required: true
    },
    status: {
      type: String,
      enum: ['Pending', 'Accepted', 'Declined'],
      default: 'Pending'
    },
  }], 
});

const Event = mongoose.model('Event', eventSchema);

module.exports = Event;
